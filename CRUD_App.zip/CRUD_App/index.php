<?php include_once('db.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD App</title>
    <style type="text/css">

/* Set a background and center the content */
body {
  background-color: #f4f4f9;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 80vh;
  padding: 20px;
}

/* Container for the content */
.container {
  width: 100%;
  max-width: 100%;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
}

/* Heading */
h1 {
  margin-bottom: 20px;
  color: black;
  background-color: #ff004f;
  padding: 10px;
  border-radius: 25px 0px 25px 0px;
}

/* Table Styling */
.table-container {
  width: 100%;
  margin-bottom: 20px;
  border-collapse: collapse;
}

table {
  width: 100%;
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
  margin-top: 10px;
}

thead {
  background-color: black;
  color: white;
}

th, td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

tr:nth-child(even) {
  background-color: #f9f9f9;
}

/* Buttons Styling */
button {
  padding: 8px 12px;
  border: none;
  border-radius: 5px;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.update-btn, .delete-btn {
  background-color: gold;
  color: white;
}

.update-btn:hover, .delete-btn:hover {
  background-color: black;
}

.delete-btn {
  background-color: #ff004f;
}

.delete-btn:hover {
  background-color: black;
}

/* Add New User Button */
.add-btn {
  padding: 10px 15px;
  background-color: darkcyan;
  color: white;
  font-size: 16px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  text-align: center;
  margin-top: 20px;
}

.add-btn a {
  color: white;
  text-decoration: none;
}

.add-btn:hover {
  background-color: cyan;
}

h4 {
  color: brown;

}

    </style>
</head>
<body>

    <div class="container">
       <?php if (isset($_GET['message'])): ?>
    <h4><?php echo htmlspecialchars($_GET['message']); ?></h4>
    <?php endif; ?>

        <h1>Users Informations</h1>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $conn->query("SELECT * FROM users");
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['name']}</td>
                                <td>{$row['email']}</td>
                                <td>{$row['phone']}</td>
                                <td>
                                    <button class='update-btn'><a href='update.php?id={$row['id']}'>Update</a></button> |
                                    <button class='delete-btn'><a href='delete.php?id={$row['id']}'>Delete</a></button>
                                </td>
                            </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <button class="add-btn"><a href="add.php">Add New User</a></button>
    </div>

</body>
</html>
