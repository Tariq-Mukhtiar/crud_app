<?php
include 'db.php';

$id = $_GET['id'];

// Delete the record
$sql = "DELETE FROM users WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    // Redirect with success message
    header('Location: index.php?message=Record+Deleted+Successfully');
    exit(); // Stop further script execution
} else {
    // Redirect with error message
    header('Location: index.php?message=Error+Deleting+Record');
    exit();
}
?>



