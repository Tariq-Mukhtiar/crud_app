<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $sql = "INSERT INTO users (name, email, phone) VALUES ('$name', '$email', '$phone')";

    if ($conn->query($sql) === TRUE) {
        $message = "<div class='success-message'>New record created successfully. <a href='index.php'>Go back to list</a></div>";
    } else {
        $message = "<div class='error-message'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <style type="text/css">
        /* General Reset */
body, h1, form, input, button {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
}

body {
  background-color: #f4f4f9;
  display: flex;
  justify-content: center;
  align-items: center;
/*  height: 100vh;*/
  padding: 20px;
}

.container {
  width: 100%;
  max-width: 500px;
  height: 400px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
}

h1 {
  margin-bottom: 20px;
  color: #333;
  background-color: #ff004f;
  padding: 10px;
  border-radius: 25px 0px 25px 0px;
}

/* Form Group */
.form-group {
  margin-bottom: 15px;
  text-align: left;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #555;
}

.form-group input {
  width: 100%;
  padding: 3px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
  outline: none;
  transition: border-color 0.3s ease;
}

.form-group input:focus {
  border-color: #007bff;
}

/* Button Styling */
button {
  width: 100%;
  padding: 12px;
  background-color: darkcyan;
  color: white;
  font-size: 16px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

button:hover {
  background-color: cyan;
}

/* Success and Error Messages */
.success-message, .error-message {
  padding: 20px;

  border-radius: 5px;
  margin-top: 20px;
  font-size: 16px;
}

.success-message {
  color: green;
}

.error-message {
  color: brown;
}

a {
  color: #007bff;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

    </style>
</head>
<body>

    <div class="container">
        <h1>Add New User</h1>
        
        <!-- Display message if set -->
        <?php if (isset($message)) echo $message; ?>

        <form method="POST">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" name="phone" required>
            </div>

            <button type="submit">Add User</button>
        </form>
    </div>

</body>
</html>

